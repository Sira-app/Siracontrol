'use client';

import dynamic from 'next/dynamic';

// Leaflet depende del objeto window del navegador, por lo que el mapa
// se carga solo en el cliente (ssr: false). Mientras carga, se muestra
// un marcador de posicion del mismo alto que el mapa.
const LiveMap = dynamic(
  () => import('./LiveMap').then((m) => m.LiveMap),
  {
    ssr: false,
    loading: () => (
      <div
        style={{ height: 500 }}
        className="flex items-center justify-center bg-neutral-50 text-neutral-400 text-sm"
      >
        Cargando mapa...
      </div>
    ),
  }
);

export function LiveLocationsCard({ organizationId }: { organizationId: string }) {
  return (
    <div className="card overflow-hidden">
      <div className="px-5 py-4 border-b border-neutral-100">
        <h3 className="text-sm font-semibold uppercase tracking-wide text-neutral-500">
          Empleados en campo
        </h3>
        <p className="text-xs text-neutral-400 mt-1">
          Actualizacion en tiempo real - ultimas 4 horas
        </p>
      </div>
      <LiveMap organizationId={organizationId} />
    </div>
  );
}
